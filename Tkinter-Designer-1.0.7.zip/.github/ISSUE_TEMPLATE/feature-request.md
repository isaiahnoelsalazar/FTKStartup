---
name: Feature request
about: use this template to request a feature
title: Feature request
labels: enhancement
assignees: ''

---

- Briefly describe your feature request
- What problem is this feature trying to solve?
- How do we know when the feature is complete?
- Is there any possible approach you have thought of? If yes then how?
- Would you like to participate in development of this feature?
